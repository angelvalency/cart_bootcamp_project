<script setup>
import ProductCard from './components/ProductCard.vue'
import CartCard from './components/CartCard.vue'
import { ref } from 'vue';

const cartItems = ref([]);

const addToCart = (product) => {
  const existingItem = cartItems.value.find(item => item.name === product.name);
  if (existingItem) {
    existingItem.quantity++;
  } else {
    cartItems.value.push({ ...product, quantity: 1 });
  }
};
</script>

<template>
  <header>

  </header>

  <main class="container">
    <ProductCard @add-to-cart="addToCart" />
    <CartCard :cartItems="cartItems" />
  </main>
</template>

<style scoped>
.container {
  display: flex;
}
</style>
