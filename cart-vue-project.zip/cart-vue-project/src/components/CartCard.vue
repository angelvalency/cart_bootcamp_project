<script setup>
import { defineProps } from 'vue';

const props = defineProps({
    cartItems: Array
});

const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
};
</script>

<template>
    <div class="keranjang">
        <h1>Cart</h1>
        <hr>
        <table class="table table-borderless">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Price</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Kaos</td>
                    <td>1</td>
                    <td>Rp.30.000</td>
                    <td><button class="btn btn-danger"
                            style="--bs-btn-padding-y: .30rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .55rem;"><img
                                src="../../src/assets/icons/trash-solid.svg" alt="" width="15px" srcset=""></button></td>
                </tr>
                <tr>
                    <td colspan="2" class="text-start fw-bold">Total Price:</td>
                    <td class="text-start fw-bold">{{ total = 0 }}</td>
                    <td colspan="2" class="text-end"><button class="btn btn-success"
                            style="--bs-btn-padding-y: .6rem; --bs-btn-padding-x: .6rem; --bs-btn-font-size: .8rem;">checkout</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<style scoped>
.keranjang {
    background-color: #ddd;
    border-radius: 5px;
    padding: 5px;
}

th {
    font-weight: bold;
}

th,
td {
    background-color: transparent;
}
</style>