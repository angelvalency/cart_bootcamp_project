<script setup>
import ProductItem from './ProductItem.vue';
import { defineProps, defineEmits } from 'vue';

const props = defineProps({
    products: Array
});

const { emit } = defineEmits();

const addToCart = (product) => {
    emit('add-to-cart', product);
};

const products = [
    {
        id: 1,
        name: 'Kaos',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit.',
        stock: 9,
        price: 'Rp30.000',
        image: '../assets/kaos.jpg'
    },
    {
        id: 2,
        name: 'Celana pendek',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit.',
        stock: 57,
        price: 'Rp30.000',
        image: '../assets/celana.jpg'
    },
    {
        id: 3,
        name: 'Hoodie',
        description: 'Lorem ipsum dolor sit amet consectetur adipisicing elit.',
        stock: 132,
        price: 'Rp30.000',
        image: '../assets/hoodie.jpg'
    }
];
</script>

<template>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Image</th>
                <th scope="col">Name</th>
                <th scope="col">Description</th>
                <th scope="col">Stock</th>
                <th scope="col">Price</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <ProductItem :product="product" v-for="product in products" :key="product.id" />
        </tbody>
    </table>
</template>

<style scoped>
th {
    font-weight: bold;
}
</style>