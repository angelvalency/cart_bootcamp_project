<script>
export default {
    props: {
        product: {
            type: Object,
            required: true
        }
    },
    methods: {
        addToCart(product) {
            this.$emit('add-to-cart', product);
        }
    }
}
</script>
        
<template>
    <tr>
        <td scope="row"><img v-bind:src="product.image" alt="Product Image"></td>
        <td>{{ product.name }}</td>
        <td>{{ product.description }}</td>
        <td>{{ product.stock }}</td>
        <td>{{ product.price }}</td>
        <td>
            <button type="submit" class="btn btn-primary tombolCart" @click="addToCart(product)"
                style="--bs-btn-padding-y: .30rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .55rem;">
                <img src="../../src/assets/icons/cart-arrow-down-solid.svg" width="20px" alt="">
            </button>
        </td>
    </tr>
</template>
