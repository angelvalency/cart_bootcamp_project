<script setup>
import ListProduct from './ListProduct.vue'
</script>

<template>
    <div class="produk">
        <h1>Product</h1>
        <hr>
        <ListProduct />
    </div>
</template>

<style scoped>
.produk {
    padding: 5px;
}
</style>